import 'package:get/get.dart';

import '../pages/home/home_controller.dart';
import '../pages/home/home_page.dart';

class AppPages {
  static final routes = [
    GetPage(
        name: '/',
        page: () => const HomePage(),
        binding: BindingsBuilder(() {
          Get.lazyPut(() => HomeController());
        })),
  ];
}
