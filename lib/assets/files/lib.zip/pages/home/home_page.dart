import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../widgets/click.dart';
import '../../widgets/desktop_page.dart';
import 'home_controller.dart';

class HomePage extends GetView<HomeController> {
  @override
  final controller = Get.put(HomeController());
  HomePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return DesktopPage(
      title: '主界面',
      body: Center(
        child: Click(
          onClick: () {
            controller.rc.next(const Center(child: Text('第二页')));
          },
          child: const Text(
            locale: Locale('zh', 'CN'),
            '点击下一页',
            style: TextStyle(fontSize: 20),
          ),
        ),
      ),
      routeController: controller.rc,
    );
  }
}
