import 'package:get/get.dart';

import '../../widgets/desktop_route.dart';

class HomeController extends GetxController {
  RouteController rc = RouteController();
}
